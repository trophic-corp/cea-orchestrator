# Rack A Document Set

Four engineering documents, byte-identical to the copies in `trophic-hardware`.
Open any `.html` file in a browser — they are self-contained, no assets, no network.

**Assembled:** 2026-09-10

---

## Contents

| File | Doc ID | Rev | Authority | Size |
|---|---|---|---|---|
| `RK-A-SYS_Rev2_systems-specification.html` | `RK-A-SYS` | 2 + addendum | AUTHORITATIVE | 93 KB |
| `RK-A-MFG_Rev2_manufacturing-pack.html` | `RK-A-MFG` | 2 | AUTHORITATIVE | 68 KB |
| `RK-A-QC_Rev3_engineering-validation-record.html` | `RK-A-QC` | 3 | SUPPORTING EVIDENCE | 57 KB |
| `RK-A-WRS_Rev3_closed-loop-water-recovery.html` | `RK-A-WRS` | 3 | AUTHORITATIVE | 43 KB |

### SHA-256 (first 16 hex, matching the repository copies)

```
45ce84cadd565825  RK-A-SYS_Rev2_systems-specification.html
f00f0e33d5b98468  RK-A-MFG_Rev2_manufacturing-pack.html
c6ede12e46e05ce8  RK-A-QC_Rev3_engineering-validation-record.html
e3e1ea9baf3ca4e1  RK-A-WRS_Rev3_closed-loop-water-recovery.html
```

Nothing was regenerated, reformatted or edited to assemble this set.

---

## Where each file belongs in the repository

Three drop straight into folders that already exist under
`products/cea/racks/rack-platform/`:

| File | Canonical path |
|---|---|
| `RK-A-SYS_Rev2_...` | `products/cea/racks/rack-platform/**design/**` |
| `RK-A-MFG_Rev2_...` | `products/cea/racks/rack-platform/**manufacturing/**` |
| `RK-A-QC_Rev3_...` | `products/cea/racks/rack-platform/**verification/**` |

The fourth does not:

| File | Canonical path |
|---|---|
| `RK-A-WRS_Rev3_...` | `products/cea/**irrigation/water-recovery/**` |

### Why the water recovery document is not a rack document

It was deliberately moved out of the rack during the migration (**ADR-003**,
**ICR-003**). The terrace reservoirs, the recovery skid, its pumps, the diverter
`FV-01` and the room distribution are sized by **room demand** and serve **every
rack** — they scale with the room, not with the rack. Filing them under the rack
makes the rack unsellable into any other building and forces every facility change
through a rack revision.

The rack's hydraulic responsibility ends at the **rack drain header outlet at
Z 200**, above the 100 mm air gap. Everything past that gap is the other document's
scope.

**Its `RK-A-` document ID is a legacy artifact** and is deliberately not being
renamed — it is cited by issued documents and by the CEA orchestrator suite, and
renaming would break working references to gain tidiness. Its product ID is `WR-A`.
See `platform/IDENTIFIER_STANDARD.md` §2.

### If you still want all four together under the rack

That is a reasonable thing to want — they are the set you read together. But
copying `RK-A-WRS` into `rack-platform/` creates a **second copy of an authoritative
document**, which is the exact failure the migration safety check screens for: two
files, one revision behind the other, and no way to tell which is current.

Two ways to get the convenience without the duplicate:

1. **A pointer file.** Put a one-line markdown stub in
   `rack-platform/` that links to the canonical path. Costs nothing, cannot go stale.
2. **Keep this bundle as a bundle.** It is a reading set, not a repository folder —
   which is what it is here.

If you want the pointer file added to the repo, say so and I will add it.

---

## What is not in this set

| Document | Where it is |
|---|---|
| `RK-A-BRIEF` Rev G — platform brief | `rack-platform/requirements/` |
| `RK-A-DWG` Rev 2 — structural drawings | `rack-platform/drawings/` |
| `RK-A-PARAM` Rev 1 — parameter master | `rack-platform/design/` |
| `RK-A R1` — release manifest | `rack-platform/release/` |
| `RK-A-ROOM` Rev 4 — Ooty room floor plan | `cea/facility-reference/ooty-room-20x12/` |

---

## Read these first

Two things in this set are safety-critical and easy to miss:

- **The 100 mm air gap** at the rack drain outlet must never be plumbed closed
  (`RK-A-SYS` §01/§11, `RK-A-WRS` §08). It is the only physical barrier keeping used
  bed water out of the source reservoir.
- **Sequential draining is mandatory**, not preferred (`RK-A-SYS` §R5). Four tiers
  draining at once puts 122.8 L/min into a DN40 stack rated 90–120 L/min. Concurrent
  *filling* is fine; concurrent draining is not.

And one thing to ignore: `RK-A-MFG` §15 cites the CAD release location as
`C:\Users\karex\Desktop\CEA_RACK_v1`. That path does not exist. The release
`RK-A R1` is at
`E:\My Drive\03_Projects\Trophic Industries\CEA_RACK_v1\INTEGRATED_v2_Rev5\`.
Recorded as an erratum in `docs/system/DOCUMENT_REGISTER.md` §5.
