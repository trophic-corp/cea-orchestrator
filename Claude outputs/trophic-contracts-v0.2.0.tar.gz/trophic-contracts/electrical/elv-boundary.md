# Electrical — ELV boundary and protection

**Version:** 0.2.0 (new) · **Derivation:** `trophic-hardware` EDR-008, interface `IF-RK-A-ELE`; RK-A-SYS Rev 2 §07; RK-A-MFG Rev 2 §01, §05; RK-A-ROOM Rev 4 §05

> v0.1.0's electrical interface listed most of this as NEEDS SPECIFICATION. The CEA suite
> audit showed it was specified in the hardware set all along. Published here.

## Contract — the ELV boundary

**All conductors at or below bed/canopy level are 24 V or 48 V DC only.**

Mains (230 V) is confined to an **IP65 enclosure mounted above canopy height**.

| Fact | Value |
|---|---|
| Minimum electrical/water vertical separation | **236 mm** |
| Cable crossing a wet zone | Not permitted without a drip loop |
| LED supply | 48 V DC, with a 0–10 V dimming pair per tier, IP65 keyed connector |
| LED drivers | Remote, in the end enclosure |
| Fan control | PWM or 0–10 V from the rack controller, with tacho feedback |

**It is the ELV boundary — not the ingress rating — that makes the electrical and water
systems genuinely independent.** An IP-rated enclosure at bed level would not be
equivalent.

## Contract — protection

| Item | Specification |
|---|---|
| RCBO type | **Type A, NOT Type AC** |
| Per rack | 16 A Type A RCBO, 30 mA |
| Per group of 8 racks | 63 A MCCB, Type 2 SPD |
| Terrace circuit | **10 mA** RCBO — tighter, because it is an outdoor/wet installation |
| Surge protection | Type 1+2 SPD at the main board; Type 2 SPD per group panel, 10 kA, max 3 m lead to earth bar |
| Earthing | TN-S per IS 3043; every rack frame bonded, continuity **< 0.1 Ω**, tested and recorded per rack |

### Why Type A specifically

LED drivers, PWM/EC fans and inverter-compressor HVAC produce **pulsating DC** residual
currents that a Type AC RCD/RCBO can fail to trip on. This is a hard requirement repeated
across every electrical section of the source set, and applies to the room distribution
board as well as the rack.

## Assertions

1. Software must not present a per-rack emergency stop — see `safety/interlocks.md`.
2. Per-rack **energy metering does not exist**. Per-rack circuits exist; no kWh meter is
   documented. Any per-rack energy figure is a **schedule-derived estimate** and must be
   provenance-marked as such, never presented as a measurement.
3. Earth continuity is a **per-rack recorded value**, not a one-off installation check.
