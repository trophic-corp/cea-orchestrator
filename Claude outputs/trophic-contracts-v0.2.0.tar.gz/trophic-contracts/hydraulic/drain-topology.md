# Hydraulic — drain topology

**Version:** 0.1.0 · **Derivation:** `trophic-hardware` EDR-006, ICR-001, ICR-003

## Contract

The drain path from every bed to the recovery system contains a **permanent
100 mm air gap** at the rack drain header outlet.

| Element | Elevation |
|---|---|
| Rack drain header outlet | Z 200 mm |
| Air gap | **100 mm** (2 × DN50) |
| Tundish rim | Z 100 mm |

Standard: IS 12234 / EN 1717.

## Assertions

1. **There is no valve at the air gap.** It cannot be closed, isolated or
   commanded.
2. Software must **not** model the drain path as closable downstream of the rack
   outlet.
3. Software must **not** raise an alarm on the openness of this path. It is open
   by design and permanently.
4. Upstream of the outlet, the drain chain is continuous from every tray outlet.
   Drain solenoids on that chain fail **open** — see `safety/valve-fail-states`.
5. The air gap is the only physical barrier preventing used bed water from
   reaching the source reservoir in a closed loop. Any design, procedure or
   automation that would bridge it is a safety violation regardless of intent.
