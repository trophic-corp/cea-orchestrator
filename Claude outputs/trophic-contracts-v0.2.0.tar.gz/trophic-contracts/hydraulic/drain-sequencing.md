# Hydraulic — drain sequencing

**Version:** 0.2.0 (new) · **Derivation:** `trophic-hardware` RK-A-SYS Rev 2 §R5 "Sequential draining is mandatory, not preferred"; RK-A-WRS Rev 3 §07

> **This contract did not exist in v0.1.0.** Its absence was the most serious gap found
> in the CEA suite audit: a reader of v0.1.0 could reasonably have concluded that
> because four tiers may *fill* concurrently, they may also *drain* concurrently. They
> may not, and doing so overflows a pipe.

## Contract

**Draining is sequential. One tier at a time. This is a hard requirement of the
pipework, not an efficiency preference.**

| Fact | Value |
|---|---|
| Single tier drain rate | 30.7 L/min |
| Four tiers draining at once | 122.8 L/min |
| DN40 vertical stack practical capacity | **90 – 120 L/min** |
| Fault case: all four **overflowing** at once | 28.8 L/min — limited by fill rate, **passes** |
| Drain rate relative to fill | ~4.2x |

Recovery-side constraint:

| Fact | Value |
|---|---|
| Recovery batch granularity | **One rack per batch** |
| Full rack drain volume | 46 L |
| Trough working volume | 79 L |
| Per-tier confirmation | `LSH-04` confirms each header is empty before the next tier drains |

## Assertions

1. **Never command more than one tier of a rack to drain at a time.** Four concurrent
   drains put 122.8 L/min into a stack whose practical capacity is 90-120 L/min.
2. The **fault** case — all four trays overflowing simultaneously through the standpipes —
   is bounded by the fill rate at 28.8 L/min and is within capacity. Overflow is safe;
   commanded concurrent draining is not. Do not infer one from the other.
3. **Recovery is batched per rack**, not per tier and not per room. The trough is sized
   for one rack's 46 L against 79 L of working volume. Draining a second rack into a
   trough already holding a batch is outside the sized design.
4. The reuse gate is evaluated on a **settled, mixed batch**, not on a moving stream —
   see `process/reuse-decision.md`. Sequencing exists partly to make that possible.
5. Sequential draining is mandatory **in all revisions**, including those where the
   supply side permits concurrent filling.

## Documented drain sequence for one recovery batch

1. One rack drains — four tiers in sequence into the trough, 46 L total.
   `LSH-04` confirms each header empty before the next tier.
2. Settle 30 s. Solids to the strainer basket, air out of the sample.
3. Test 3 min. `AT-03`, `AT-04` and `TE-02` read as **60-second rolling means** on the
   mixed batch, never spot values on a moving stream.
4. Evaluate the batch gates. See `process/reuse-decision.md`.
