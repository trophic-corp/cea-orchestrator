# Hydraulic — supply limits

**Version:** 0.2.0 · **Derivation:** `trophic-hardware` EDR-005, ICR-002, interface `IF-RK-A-HYD`; RK-A-SYS Rev 2 R5; RK-A-WRS Rev 3 §02

> **Changed in 0.2.0.** v0.1.0 stated "four tiers concurrent — permitted" without
> qualifying it. That is true of **filling only**. Draining is a different constraint
> and is now published separately in `hydraulic/drain-sequencing.md`, which is
> **mandatory reading alongside this file**.

## Contract

| Fact | Value |
|---|---|
| Supply type | **Gravity** |
| Supply pump | **None exists** |
| Source outlet elevation | +4250 mm |
| Static head at the top nozzle (+1590 mm) | 2.66 m |
| Single-tier design fill flow | 7.2 L/min |
| Rack-side loss at design flow | 0.33 m |
| Four tiers **filling** concurrently | 28.8 L/min at 0.67 m — **permitted** |
| **Fill flow ceiling** | ~15 L/min through a single path before head is exhausted |

## Assertions

1. **Supply pressure is not constant and cannot be commanded.** It varies with source
   tank level and with concurrent draw. Software must not assume a fixed pressure, and
   must not interpret a slow fill as a fault without checking concurrency.
2. **Concurrent filling is permitted.** The sequential-fill rule that existed in earlier
   revisions was a pump-sizing constraint (7.2 L/min pump, DN20 branch). It is
   **superseded on the supply side** by the terrace gravity-feed design: gravity has
   spare head to flood all four tiers of a rack at once.
3. **Concurrent draining is NOT permitted.** See `hydraulic/drain-sequencing.md`. The
   supersession in assertion 2 applies to the supply side only.
4. There is no pump to compensate for an increase in nozzle count, tier count or
   solenoid restriction. Any such change is a hardware recalculation.
5. Supply survives a power failure. Loss of power does not stop water being available; it
   stops the fill valves opening.

## Note on a numeric discrepancy

The rack specification gives the four-tier concurrent **fill** rate as **28.8 L/min**
(4 x 7.2). The pump-duty analysis that rejected simultaneous filling on the old pumped
design quotes **29.0 L/min** for the same arrangement. The two figures describe the same
physical case on different bases; **28.8 L/min is the figure to use**, because it is the
one the current gravity design and its fault case are computed from. Flagged rather than
silently harmonised.
