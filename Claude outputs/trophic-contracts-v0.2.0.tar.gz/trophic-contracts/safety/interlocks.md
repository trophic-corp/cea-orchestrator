# Safety — interlocks

**Version:** 0.2.0 (new) · **Derivation:** `trophic-hardware` RK-A-SYS Rev 2 §01, §05, §07, §11; RK-A-WRS Rev 3 §07, §08; RK-A-MFG Rev 2 §01, §02, §12

> v0.1.0 listed interlocks as blocked. They are not — they are specified in the hardware
> set. Published here.

## Contract — hard-wired interlocks

These are **hard-wired and bus-independent**. Software reads their state; **software is
not in their safety path**.

| Interlock | Trip condition | Action | Where |
|---|---|---|---|
| Rack leak puck | Water at the drain header | Rack fill solenoids close | Per rack, hard-wired to the rack controller |
| Room floor flood sensor | Water on the room floor | `MV-01` closes | Hard-wired to `MV-01` |
| Header high-level switch `LSH-04` | Header not empty | Blocks the next tier drain | Per rack |
| **E-stop** | Manual | Drops the group contactor, all fill solenoids, `MV-01`, all pumps. Drains **de-energize open** | **Room level, one latching mushroom head per aisle/door** |
| CO₂ safety | 5000 ppm | Fail-closed solenoid, independent monitor | Room, low-level NDIR at 300 mm |
| Solution over-temperature | > 28 °C | `MV-01` inhibited | `TE-01` / `TE-02` |
| Flow over-delivery | 1.3 x expected on the down-main totaliser | Close `MV-01`, alarm | Down-main |
| Filter differential pressure | >= 1.0 bar | Inhibit `P-02`, alarm | `PDI-01` |
| Pump run limit | 4 min | `P-02` stops — catches a stuck float | `P-02` |

## Assertions

1. **The E-stop is room-level, not per-rack, and that is deliberate.** Sixteen rack-level
   E-stops are sixteen devices nobody can reach in an emergency. The **per-rack isolator
   is for lock-out/tag-out maintenance** — a different function, not an E-stop. Software
   must not present a per-rack emergency stop, and must not treat the rack isolator as one.
2. While the E-stop is engaged, conflicting commands are **refused with a reason**, not
   queued. The platform should be able to show exactly what the E-stop dropped.
3. An interlock-tripped zone is **inhibited until an operator explicitly clears it with a
   reason**. Nothing auto-resumes.
4. **Solution over-temperature has two distinct thresholds**: an alarm at **26 °C**
   (also gate G3, which holds 60 min and re-tests before dumping) and a hard `MV-01`
   inhibit at **28 °C**. They are not the same event.
5. Anything acting on a **single sensor's word** for a safety decision is a design
   violation. Where two instruments exist (two NDIRs, room vs rack T/RH), divergence marks
   both suspect.

## Commissioning hold point

**Fill solenoids must be proven to close within 60 seconds** during commissioning, with a
deliberately blocked drain.

This is a **QC hold point, not a design assumption**. It is not satisfied by analysis, by
simulation, or by the datasheet — only by the test.
