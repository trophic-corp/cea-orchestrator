# Safety — valve and actuator fail states

**Version:** 0.2.0 · **Derivation:** `trophic-hardware` EDR-007, interface `IF-RK-A-CTL` §2; RK-A-WRS Rev 3 §08; RK-A-SYS Rev 2 §01, §11, R4

> **Expanded in 0.2.0** from four devices to the full wet-side table, after the CEA suite
> audit found the software already carrying a more complete table than this contract
> published.

## Contract — de-energized (power-loss) state of every controlled wet-side device

| Device | Fail state | Why |
|---|---|---|
| Rack fill solenoids | **CLOSED** | No bed fills unattended |
| Rack drain solenoids | **OPEN** | Beds self-drain; no standing water on a dead rack |
| Terrace master supply valve `MV-01` | **CLOSED** (spring-return) | The only thing holding back a full terrace reservoir must not be electricity |
| Diverter valve `FV-01` | **TO WASTE** | Unverified water can never enter the rising main without power *and* a passed gate |
| Trough dump valve | **CLOSED** | A power cut must not silently discard a good, gate-passed batch |
| Make-up valve | **MECHANICAL float, not a solenoid** | Keeps working through a power cut by design, not by control logic |
| Transfer pumps `P-02`, `UV-01`, `DOS-01` | **OFF** | |
| CO₂ safety solenoid | **CLOSED** (fail-closed) | Room-level; independent monitor |
| Vacuum breaker | **Passive** | At the down-main high point; prevents a downstream failure siphoning the terrace tank |

## Assertions

1. **Every valve is safe with no power and no signal.** Software drives valves *away*
   from safe.
2. **Loss of control authority is not a hazard.** Software must never be written as though
   it is responsible for commanding a safe state, must not implement a watchdog whose
   action is to command safety, and must not treat a communications loss as an emergency
   requiring actuation.
3. Aggregate failure state: beds drain by gravity, supply isolates, recovery discards to
   waste, a good batch is retained, make-up keeps working.
4. Crop stress on failure is an accepted design outcome. It is the lesser failure against
   flooding the room or contaminating the source reservoir.
5. **Firmware boots to these states before schedules resume.** Power restoration is not
   the moment to re-apply a desired state; it is the moment to prove the fail-safe.
6. The rationale for drain-open specifically: both valves normally closed would leave
   roots standing in water for the duration of an outage — anoxia and root rot from what
   should have been a harmless power cut. The cost is that drain valves are energised
   through the dwell, about **8 W each**; at 1-3 cycles a day that is negligible.

## Overflow design rule (normative)

Every vessel keeps a **gravity overflow one nominal size larger than its largest inlet**,
terminating with a **visible air gap**.

An overflow that discharges into a closed pipe **is not an overflow** — it becomes a
second way to pressurise the tank. This is a design rule, not a preference, and it
applies to every vessel in the system.

## Consequence for procurement and commissioning

Valves are specified by fail position, not only by size and voltage. A substituted valve
with the opposite polarity silently inverts this contract and **will not be detected by
software**.
