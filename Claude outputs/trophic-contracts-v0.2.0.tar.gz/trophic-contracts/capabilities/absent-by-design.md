# Capabilities — absent by design

**Version:** 0.2.0 (new) · **Derivation:** `trophic-hardware` RK-A-SYS Rev 2; RK-A-WRS Rev 3; RK-A-ROOM Rev 4

These are **not gaps waiting to be filled**. They are engineering decisions with stated
rationale, and software that quietly assumes them into existence will be wrong about the
room.

| Capability | Status | Rationale from the hardware set |
|---|---|---|
| **Per-tray water level sensing** | **ABSENT by design** | The overflow standpipe sets level mechanically — this deletes sixteen sensors per rack |
| **Per-rack or per-tier CO₂ sensing** | **ABSENT, explicitly rejected** | It measures the same room sixteen times and costs sixteen times as much |
| **Per-tier temperature / humidity control** | **ABSENT — room scope by design** | Room HVAC owns bulk temperature, humidity and CO₂ |
| Per-tier T/RH **sensing** | **OPTIONAL** (Pro/R&D build). Rack-level, one per rack at tier 3, is standard | |
| **Fixed PAR / PPFD sensor** | **ABSENT — portable only** | Quantum sensor on a jig at commissioning and quarterly |
| **Per-rack electricity metering** | **ABSENT** | Per-rack circuits exist; no kWh meter documented |
| IR leaf temperature (true VPD) | **OPTIONAL**, Pro only | |
| Imaging / phenotyping | **OPTIONAL / FUTURE** — sourcing entry only, nothing installed | |

## Assertions

1. A control must not appear in a UI for a capability the hardware does not have.
2. **PPFD is a commissioning and quarterly verification, not a closed loop.** The
   operating band is **150 – 210 µmol/m²/s with CV <= 15 %**, verified by portable
   quantum sensor traverse. Below 100 suppresses growth; above 210 risks
   photoinhibition. Software may schedule and dim, but it cannot measure PPFD in service.
3. **VPD is computed from T and RH by the controller — never sensed directly.**
4. Climate and CO₂ parameters carried on a tier-scoped recipe are **advisory at tier
   scope, directive at room scope**. Record them as the tier's demand; the actuator lives
   at room level. Never pretend tier-level climate control the hardware does not have.
5. Any per-rack energy figure is an estimate — see `electrical/elv-boundary.md`.
