# Changelog

All contract changes are reviewed events. Nothing changes here as a side effect of a
hardware CAD edit.

## [0.2.0] — 2026-09-09

Issued after auditing the CEA orchestrator suite (`trophic-corp/cea-orchestrator`) against
v0.1.0. The suite had independently extracted hardware facts from the same source
documents; this release publishes what both sides should have been reading from one place,
and corrects what the extraction got wrong.

### Added
- `hydraulic/drain-sequencing.md` — **sequential draining is mandatory.** The most
  serious gap in v0.1.0
- `safety/interlocks.md` — hard-wired interlock table, E-stop scope, the 60 s
  commissioning hold point. v0.1.0 wrongly listed interlocks as unspecified
- `electrical/elv-boundary.md` — ELV boundary, 236 mm separation, RCBO ratings, SPD,
  earthing. v0.1.0 wrongly listed most of this as unspecified
- `capabilities/absent-by-design.md` — capabilities the hardware deliberately does not
  have, with rationale
- `sensors/instrument-tags.md` — the tag vocabulary, controller topology and per-rack
  actuator counts

### Changed
- `hydraulic/supply-limits.md` — **corrected.** v0.1.0 said "four tiers concurrent —
  permitted" without qualification. True of filling only; draining is now its own contract
- `process/reuse-decision.md` — expanded from prose to the full **eight**-gate table with
  thresholds, instrument tags, per-batch vs continuous evaluation, and the transfer
  sequence. v0.1.0 wrongly called the thresholds "operational configuration"
- `safety/valve-fail-states.md` — expanded from 4 devices to the full wet-side table;
  added the normative overflow design rule
- `geometry/bed-datum.md` — added flood geometry (22 / 30 / 47 mm) and the standpipe bore
  decision; added the absence of per-tray level sensing
- `conventions/units.md` — added EC, PPFD, airflow, CO₂, UV dose units and the full
  instrument tag patterns

### Corrections issued against the CEA suite
- **G1 EC gate.** `safety-rules.json` records the multiplier as `~1.2x` from a garbled
  OCR read and marks the gate unsafe to code. The authoritative source reads
  **`<= 1.5 x setpoint — <= 1.80 mS/cm at a 1.20 setpoint`**. The multiplier is 1.5, not
  1.2; 1.20 is the setpoint, not the multiplier. The gate is codeable; the OCR flag can
  be cleared. See `process/reuse-decision.md`
- **Gate count.** The suite documents G1–G5. There are **eight** gates, and G4/G5 are
  evaluated continuously during transfer while the rest are per-batch
- **Room document revision.** The suite's device model cites RK-A-ROOM **Rev 3**. The
  current revision is **Rev 4**, which restored the Building section (ceiling height,
  floor and point loading, slab, wall fixings, egress) that Rev 3 silently dropped

### Still not published
Modbus register maps, per-tier sensor mounting coordinates in bed-datum terms, consolidated
sensor ranges and accuracy classes, and the LED driver model. All remain hardware
deliverables. See `sensors/instrument-tags.md`.

## [0.1.0] — 2026-09-09

Initial publication. Extracted from `trophic-hardware` at the migration consolidation
commit.

### Added
- `conventions/units.md`
- `safety/valve-fail-states.md` — from EDR-007
- `hydraulic/supply-limits.md` — from EDR-005, ICR-002
- `hydraulic/drain-topology.md` — from EDR-006, ICR-001, ICR-003
- `geometry/bed-datum.md` — from EDR-001
- `process/reuse-decision.md` — from ADR-001, EDR-009
