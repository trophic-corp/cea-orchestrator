# Sensors and actuators — instrument tags

**Version:** 0.2.0 (new) · **Derivation:** `trophic-hardware` RK-A-WRS Rev 3 §07; RK-A-SYS Rev 2

The tag list the hardware documents actually use. Published so that hardware and software
name the same device the same way.

> **This is not yet a complete device inventory.** It is the set of tags that appear in
> the authoritative hardware documents. A full per-tier actuator and sensor tabulation
> with ranges, accuracies and mounting coordinates is still a hardware deliverable — see
> "Still missing" below.

## Water side

| Tag | Device | Location |
|---|---|---|
| `TK-01` | Source reservoir | Terrace |
| `LT-02` | Level transmitter for `TK-01` | Terrace |
| `TE-01` | Temperature element | In `TK-01` |
| `TE-02` | Temperature element | In the trough |
| `AT-03` | **Electrical conductivity** analyser | In the trough |
| `AT-04` | **pH** analyser | In the trough |
| `LSH-04` | Header high-level switch | Per rack drain header |
| `LS-01` | Low-level switch | Trough |
| `LD-01`…`LD-11` | Leak detection pucks | One per rack (11 racks) |
| `F-01`, `F-02` | Filters | Water skid |
| `PDI-01` | Filter differential pressure indicator | Across `F-01` + `F-02` |
| `UV-01` | UV disinfection unit | Water skid |
| `UIT-01` | UV intensity transmitter | On `UV-01` |
| `FS-01` | Flow switch — transfer proof | Rising main |
| `P-02` | Recovery transfer pump, duty/standby A/B | Trough, at the low point |
| `DOS-01` | Fertigation dosing — A + B + acid, peristaltic, EC-proportional | Rising main |
| `MV-01` | Terrace master supply valve | Terrace |
| `FV-01` | Recovery diverter valve | Terrace |

`P-02` duty: **25 L/min at 20 m, 0.75 kW**. Static lift 4.76 m (trough at 87 mm to tank
inlet at 4850 mm); clean duty 12.4 m, 18.9 m at the 1.0 bar filter-change limit.

## Controllers and bus

| Item | Detail |
|---|---|
| Rack controllers | 11 x ESP32 + 8-channel relay + RS485. Own the tier fill/dwell/drain sequence, fan PWM, and the leak/header interlocks. Hold a last-known-good schedule |
| Room controller | Bus master, local time-series store, local UI, UPS. Owns the drain token, the eight-condition reuse gate, dosing, HVAC and CO₂ setpoints, alarms, the local log |
| I/O nodes | Terrace, water skid, room — 14 bus nodes in total |
| In-room bus | **Modbus RTU over RS485**, multi-drop, 120 Ω both ends. Wired-first: a room of galvanised racks is a poor 2.4 GHz environment |

**The cloud owns remote view and history — and nothing the room depends on.**

## Per-rack actuator count

| Item | Count |
|---|---|
| Fill solenoids | 4 (one per tier), normally closed |
| Drain solenoids | 4 (one per tier), normally open |
| Relay channels | 8 |
| EC fans | 1 per tier, 178 m³/h, PWM or 0–10 V, **tacho feedback — the tacho alarm is not optional** |
| LED dimming pairs | 1 x 0–10 V per tier; two bars share one pair |

## Still missing — hardware deliverables

| Item | Status |
|---|---|
| Per-tier sensor mounting coordinates in bed-datum terms | Modelled in CAD; not tabulated |
| Sensor ranges, accuracy classes and calibration intervals per tag | Partially in the Phase D BOM; not consolidated |
| Modbus register map per node | Not published |
| MQTT payload schema version | Owned by the software side (ADR-0004); hardware must review |
| LED driver model | **Not chosen** — determines whether photoperiod off is dim-to-off or a relay |
