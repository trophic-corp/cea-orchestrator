# Geometry — bed datum and flood geometry

**Version:** 0.2.0 · **Derivation:** `trophic-hardware` EDR-001, interface `IF-RK-A-MEC` §3; RK-A-SYS Rev 2 §01, §05, §11

## Contract — the datum

**A bed datum is the top face of the deck mesh panel.**

Not the beam. Not the deck rail. Not the tray floor. Not the water surface.

| Fact | Value |
|---|---|
| Tiers per rack | 4 |
| Bed datums | **300 / 700 / 1100 / 1500 mm** above floor |
| Tier pitch | 400 mm |

Deck build-up below each datum, first tier:

| Element | Z range |
|---|---|
| Beam | 243.4 – 273.4 |
| Deck rail | 273.4 – 298.4 |
| Deck mesh panel | 298.4 – **300.0** |
| Tray | from 300.0 |

## Contract — flood geometry (new in 0.2.0)

Measured from the tray floor:

| Element | Height | Meaning |
|---|---|---|
| **Working flood depth** | **22 mm** | The controlled setpoint |
| **Standpipe collar crest** | **30 mm** | Mechanical overflow — above the working flood |
| **Tray rim** | **47 mm** | Physical containment — above the crest |
| Dwell | **10 min** | |
| Standpipe minimum bore | **DN32** | DN25 was rejected: it passes exactly the fill rate at 8 mm head over the crest, i.e. zero margin. DN32 passes 11.9 L/min, a 1.65x margin |

## Assertions

1. **All level and flood-depth setpoints reference the bed datum.** A setpoint expressed
   against the tray floor or the beam is wrong by a known but non-obvious offset.
2. Tier indices map to datums in ascending order: tier 1 = 300 mm, tier 2 = 700 mm,
   tier 3 = 1100 mm, tier 4 = 1500 mm.
3. Four tiers is the maximum for this rack and is reach-limited, not structure-limited.
   Software must not generalise over an arbitrary tier count without a hardware change.
4. **There is no per-tray level sensor, by design.** The overflow standpipe sets level
   mechanically — this deletes sixteen sensors per rack. Software must not expect a
   measured tray level, must not derive one, and must not alarm on its absence. Level is
   sensed at **system** points only: `TK-01` (`LT-02`), trough floats x3, header
   (`LSH-04`), and the mechanical make-up float.
5. The fill solenoid runs on a **timer**. If it sticks open, the standpipe at 30 mm is
   what prevents the tray reaching the 47 mm rim. The timer is control; the standpipe is
   safety. Do not treat the timer as the containment.
