# trophic-contracts

**Version 0.2.0**

Stable, machine-consumable interface facts published by Trophic **hardware** for Trophic
**software** to consume.

This repository is deliberately thin. It exists so that the CEA orchestrator never needs
to read the hardware engineering repository — and so that it never again has to extract
hardware facts from OCR'd PDFs on its own.

## What is here

| Path | Contract |
|---|---|
| `conventions/units.md` | Units and instrument tag patterns |
| `safety/valve-fail-states.md` | De-energized state of every wet-side device; the overflow rule |
| `safety/interlocks.md` | Hard-wired interlocks, E-stop scope, commissioning hold point |
| `hydraulic/supply-limits.md` | Gravity supply head and **fill** limits |
| `hydraulic/drain-sequencing.md` | **Sequential draining is mandatory** |
| `hydraulic/drain-topology.md` | The permanent air gap in the drain path |
| `geometry/bed-datum.md` | What a bed height is measured from; flood geometry |
| `process/reuse-decision.md` | The eight-condition reuse gate and transfer sequence |
| `electrical/elv-boundary.md` | ELV boundary, protection, earthing |
| `capabilities/absent-by-design.md` | What the hardware deliberately does not have |
| `sensors/instrument-tags.md` | Tag vocabulary, controller topology, actuator counts |

## The three that most often go wrong

1. **Draining is sequential; filling is not.** Four tiers filling at once is fine. Four
   tiers draining at once puts 122.8 L/min into a stack rated 90–120.
2. **Every valve is already safe with no power.** Software drives valves *away* from safe.
   Losing control authority is not an emergency.
3. **A bed height is measured from the deck mesh top face**, not the tray floor.

## What is deliberately not here

Geometry, drawings, CAD files, BOMs, costs, simulation records, floor plans and supplier
research. If a contract cannot be stated without geometry, it does not belong here.

## What is missing and why

Modbus register maps, per-tier sensor mounting coordinates, consolidated sensor ranges and
accuracy classes, and the LED driver model are **not yet published** because they have not
yet been specified on the hardware side. They are hardware deliverables. Placeholders are
not provided, because a placeholder contract is worse than a missing one.

## Rules

1. Every contract states its **derivation** — the hardware decision or document section it
   came from. This is what makes drift detectable.
2. Every change gets a `CHANGELOG.md` entry and review by both sides.
3. Contracts are versioned. Consumers pin a version; they do not track a branch.
4. `trophic-hardware` and the CEA orchestrator repository are independent of each other.
   Neither ingests the other. **This repository is the only channel.**
5. Where this repository and a consumer's local copy of a hardware fact disagree, **this
   repository wins** — and the disagreement gets a CHANGELOG entry, not a silent fix.
