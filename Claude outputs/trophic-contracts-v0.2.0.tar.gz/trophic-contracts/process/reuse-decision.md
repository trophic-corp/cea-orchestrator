# Process — recovered water reuse gate

**Version:** 0.2.0 · **Derivation:** `trophic-hardware` RK-A-WRS Rev 3 §07; ADR-001, EDR-009

> **Substantially expanded in 0.2.0.** v0.1.0 described the reuse decision in prose and
> said thresholds were "operational configuration". They are not — they are sourced
> engineering values, there are **eight** gates, and two of them are evaluated
> continuously rather than per batch.

## Contract — the eight-condition gate

| Gate | Condition | Threshold | Measured at | On failure |
|---|---|---|---|---|
| **G1** | Electrical conductivity | **<= 1.5 x setpoint** — i.e. <= 1.80 mS/cm at a 1.20 setpoint | `AT-03`, in the trough | Trough dump valve to waste |
| **G2** | pH | **4.5 – 7.5** | `AT-04`, in the trough | Dump to waste |
| **G3** | Temperature | **<= 26 °C** | `TE-02`, in the trough | Hold 60 min, re-test, then dump |
| **G4** | Filter differential pressure | **< 1.0 bar** across `F-01` + `F-02` | `PDI-01` | Inhibit `P-02`, alarm, change elements |
| **G5** | Disinfection proven | `UIT-01` **>= 70 %** of rated **and** lamp on **and** `FS-01` made | `UV-01` | `FV-01` to waste mid-transfer |
| **G6** | Leak detectors clear | No leak puck active this cycle | `LD-01…11` | Dump to waste; isolate that rack |
| **G7** | Operator contamination hold | Not set | Controller | Dump to waste until cleared by a **named** operator |
| **G8** | `TK-01` has room | `LT-02` **< 90 %** | Terrace | Hold in trough until level falls |

### When each gate is evaluated

| Timing | Gates |
|---|---|
| **Per batch, before anything is pumped** | G1, G2, G3, G6, G7, G8 |
| **Continuously, during transfer** | G4, G5 — either failing throws `FV-01` to waste mid-transfer |

Fail on any batch gate → the trough dump valve opens to waste and the event is logged
**with the failing gate named**. Nothing is pumped.

## Transfer sequence

1. **UV pre-strike.** On a pass, `UV-01` energises and holds **60 s** of amalgam warm-up
   before the pump starts.
2. **Transfer.** `P-02` runs; `FS-01` must make within **10 s**.
3. **Dose on the way up.** `DOS-01` injects A, B and acid into the rising main,
   proportional to the trough EC deficit against setpoint.
4. **Stop.** `P-02` stops on `LS-01` low **or** a **4-minute run limit**, whichever comes
   first. The run limit is specifically what catches a stuck float.
5. **Blowdown.** Daily at **02:00**, the first batch is dumped **regardless of gate
   result**. This is deliberate sodium control. **It is not an error condition and must
   not be alarmed as one.**

## Assertions

1. **The default on uncertainty is discard.** `FV-01` fails to waste. An unavailable or
   stale water-quality reading is a reason to discard, never a reason to return.
2. **The supply side has no gate.** Water in `TK-01` has already passed once, but it sits
   on a roof between uses, warming and concentrating by evaporation. Do not assume stored
   water is still within the gate that admitted it.
3. Gate readings are **60-second rolling means on a settled, mixed batch**. Spot values on
   a moving stream are not a valid gate input.
4. G7 is an operator hold that can only be cleared by a **named** operator. It is not
   auto-clearing and not time-expiring.
5. UV disinfection design dose is **100 mJ/cm²** for oomycete and bacterial control
   (Pythium, Fusarium). G5 gates on intensity, not on dose directly.
6. Above 26 °C dissolved oxygen falls (9.1 mg/L at 20 °C to 7.6 at 30 °C) and *Pythium*
   zoospore activity rises sharply. `MV-01` is inhibited above **28 °C** — see
   `safety/interlocks.md`.
7. **Where UV-C is in the loop, dissolved iron requires monthly verification.** UV-C
   degrades Fe-EDTA; the chelate must be Fe-DTPA or Fe-EDDHA. The failure is silent —
   iron precipitates while the dosing record shows iron was added — so it will not be
   caught by dosing logic.

## Correction issued against the CEA suite

`.github/agentic-rules/safety-rules.json` records G1 as
*"EC < setpoint x ~1.2"* and marks the numeric threshold as OCR-garbled and unsafe to
code (`"< 15 setpoint — < 180 mS/cm at a 1.20 setpoint"`).

The authoritative source, RK-A-WRS Rev 3 §07, reads:

> **G1 Electrical conductivity — <= 1.5 x setpoint — <= 1.80 mS/cm at a 1.20 setpoint —
> AT-03, in the trough — Trough dump valve to waste**

So: the multiplier is **1.5x, not 1.2x**. `1.20` is the **EC setpoint** in the worked
example, not the multiplier, and `1.80 mS/cm` (not 180) is the resulting limit. The gate
is now codeable. The OCR flag on this value can be cleared.

**The EC operating setpoint itself remains unspecified.** `1.20 mS/cm` appears only as
the worked example in the gate formula; no source states it as the operating target. G1
is codeable as a *formula*; its *setpoint input* is still a domain-expert TBD.
