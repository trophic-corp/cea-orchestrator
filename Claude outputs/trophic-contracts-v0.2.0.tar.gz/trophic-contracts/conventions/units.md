# Conventions — units and identifiers

**Version:** 0.2.0 · **Derivation:** `trophic-hardware` document set, uniform usage

## Units

| Quantity | Unit |
|---|---|
| Length | mm |
| Flow | L/min |
| Head | m water |
| Volume | L |
| Mass | kg |
| Pressure | kPa (bar for filter differential pressure) |
| Electrical conductivity | **mS/cm** |
| Photosynthetic photon flux density | **µmol/m²/s** |
| Air flow | m³/h |
| Air velocity | m/s |
| CO₂ | µmol/mol for the enrichment target, **ppm** for the safety alarm |
| Vapour pressure deficit | kPa |
| UV dose | mJ/cm² |
| Torque | N·m |
| Resistance | Ω |

All lengths are millimetres. There are no centimetres or metres in hardware geometry,
with the single exception of head, which is metres of water.

## Identifiers

| Pattern | Meaning | Example |
|---|---|---|
| `RK-A-###` | Rack A part number | `RK-A-104` |
| `TK-##` | Tank / reservoir | `TK-01` |
| `TE-##` | Temperature element | `TE-02` |
| `AT-##` | Analyser transmitter (EC, pH) | `AT-03` |
| `LT-##` / `LS-##` / `LSH-##` | Level transmitter / switch / high switch | `LSH-04` |
| `LD-##` | Leak detector | `LD-07` |
| `F-##` / `PDI-##` | Filter / differential pressure indicator | `PDI-01` |
| `UV-##` / `UIT-##` | UV unit / UV intensity transmitter | `UIT-01` |
| `FS-##` | Flow switch | `FS-01` |
| `P-##` | Pump | `P-02` |
| `DOS-##` | Dosing unit | `DOS-01` |
| `MV-##` | Master valve | `MV-01` |
| `FV-##` | Flow / diverter valve | `FV-01` |
| `G#` | Reuse gate | `G5` |
| `T##` | Acceptance test (RK-A-QC, T1–T18) | `T16` |
| `C##` | Room circuit | `C12` |

## Coordinate convention

Rack-local coordinates. **Y is measured from the rack front face**, increasing toward the
rear. **Z is measured from the floor**, increasing upward. Flood geometry is the
exception: flood depth, standpipe crest and tray rim are measured **from the tray floor**.
